﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VN_font_maker
{
    public partial class FontEditForm : Form
    {
        private Bitmap editableBitmap;
        private PictureBox canvas;
        private Button saveButton;

        private bool isDrawing = false;
        private bool drawBlack = true;

        private int offsetY;
        private int pixelSize = 16; // Kích cỡ hiển thị mỗi pixel

        public Bitmap EditedBitmap => editableBitmap;

        public FontEditForm(Bitmap source, int offsetY)
        {
            this.Text = "Font Edit";
            this.offsetY = offsetY;

            editableBitmap = new Bitmap(source);

            int pixelSize = 16;
            int canvasWidth = editableBitmap.Width * pixelSize;
            int canvasHeight = (editableBitmap.Height + offsetY) * pixelSize;

            int margin = 20;

            canvas = new PictureBox
            {
                Location = new Point(margin, margin),
                Size = new Size(canvasWidth, canvasHeight),
                BorderStyle = BorderStyle.FixedSingle
            };

            canvas.Paint += Canvas_Paint;
            canvas.MouseDown += Canvas_MouseDown;
            canvas.MouseMove += Canvas_MouseMove;
            canvas.MouseUp += (s, e) => isDrawing = false;

            saveButton = new Button
            {
                Text = "Lưu",
                Location = new Point(margin, canvas.Bottom + 10),
                Width = 60
            };
            saveButton.Click += (s, e) => DialogResult = DialogResult.OK;

            // Tính toán kích thước form dựa trên margin + khoảng cách nút
            int formWidth = canvas.Right + margin;
            int formHeight = saveButton.Bottom + margin;

            this.ClientSize = new Size(formWidth, formHeight);

            Controls.Add(canvas);
            Controls.Add(saveButton);
        }

        private void Canvas_Paint(object sender, PaintEventArgs e)
        {
            int bmpWidth = editableBitmap.Width;
            int bmpHeight = editableBitmap.Height;

            // Vẽ vùng offsetY (trống)
            using (Brush b = new SolidBrush(Color.Yellow))
            {
                e.Graphics.FillRectangle(b, 0, 0, canvas.Width, offsetY * pixelSize);
            }

            // Vẽ bitmap (dưới offset)
            e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            e.Graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.Half;
            e.Graphics.DrawImage(editableBitmap,
                new Rectangle(0, offsetY * pixelSize, canvas.Width, bmpHeight * pixelSize));

            // Vẽ lưới
            using (Pen gridPen = new Pen(Color.Gray, 1))
            {
                for (int x = 0; x <= bmpWidth; x++)
                    e.Graphics.DrawLine(gridPen, x * pixelSize, 0, x * pixelSize, canvas.Height);

                for (int y = 0; y <= bmpHeight + offsetY; y++)
                    e.Graphics.DrawLine(gridPen, 0, y * pixelSize, canvas.Width, y * pixelSize);
            }
        }

        private void Canvas_MouseDown(object sender, MouseEventArgs e)
        {
            isDrawing = true;
            drawBlack = (e.Button == MouseButtons.Left);
            EditPixelAtMouse(e.X, e.Y);
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing)
                EditPixelAtMouse(e.X, e.Y);
        }

        private void EditPixelAtMouse(int mouseX, int mouseY)
        {
            int bmpWidth = editableBitmap.Width;
            int bmpHeight = editableBitmap.Height;

            int pixelX = mouseX / pixelSize;
            int pixelY = (mouseY / pixelSize) - offsetY; // trừ offset để đúng hàng thực

            if (pixelX >= 0 && pixelX < bmpWidth && pixelY >= 0 && pixelY < bmpHeight)
            {
                Color targetColor = drawBlack ? Color.Black : Color.White;

                if (editableBitmap.GetPixel(pixelX, pixelY).ToArgb() != targetColor.ToArgb())
                {
                    editableBitmap.SetPixel(pixelX, pixelY, targetColor);
                    canvas.Invalidate();
                }
            }
        }
    }
}
