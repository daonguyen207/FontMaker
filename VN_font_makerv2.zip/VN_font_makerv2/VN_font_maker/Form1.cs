﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography;

namespace VN_font_maker
{
    public partial class Form1 : Form
    {
        List<MyFont_typedef> fontList = new List<MyFont_typedef>();

        public Form1()
        {
            InitializeComponent();
        }
        Font font_select;
        string fontName;
        float fontSize;
        int maxHChar, maxStartHChar;

        // Trích dữ liệu byte từ .cpp
        static byte[] ExtractByteArray(string text, string varName)
        {
            string pattern = $@"const\s+uint8_t\s+PROGMEM\s+{Regex.Escape(varName)}\s*\[\s*\]\s*=\s*\{{(.*?)\}};";
            var match = Regex.Match(text, pattern, RegexOptions.Singleline);
            if (!match.Success)
            {
                Console.WriteLine($"❌ Không match được byte array: {varName}");
                return null;
            }

            return ParseByteArray(match.Groups[1].Value);
        }


        // Trích dữ liệu ushort từ .cpp
        static ushort[] ExtractUShortArray(string text, string varName)
        {
            string pattern = $@"const\s+uint16_t\s+PROGMEM\s+{Regex.Escape(varName)}\s*\[\s*\]\s*=\s*\{{(.*?)\}};";
            var match = Regex.Match(text, pattern, RegexOptions.Singleline);
            if (!match.Success)
            {
                Console.WriteLine($"❌ Không match được ushort array: {varName}");
                return null;
            }

            return ParseUShortArray(match.Groups[1].Value);
        }


        static byte[] ParseByteArray(string input)
        {
            var parts = input.Split(new[] { ',', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            var list = new List<byte>();

            foreach (var part in parts)
            {
                string s = part.Trim();
                if (s.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                {
                    if (byte.TryParse(s.Substring(2), System.Globalization.NumberStyles.HexNumber, null, out byte hexVal))
                        list.Add(hexVal);
                }
                else
                {
                    if (byte.TryParse(s, out byte decVal))
                        list.Add(decVal);
                }
            }

            return list.ToArray();
        }

        static ushort[] ParseUShortArray(string input)
        {
            var parts = input.Split(new[] { ',', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            var list = new List<ushort>();

            foreach (var part in parts)
            {
                string s = part.Trim();
                if (s.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                {
                    if (ushort.TryParse(s.Substring(2), System.Globalization.NumberStyles.HexNumber, null, out ushort hexVal))
                        list.Add(hexVal);
                }
                else
                {
                    if (ushort.TryParse(s, out ushort decVal))
                        list.Add(decVal);
                }
            }

            return list.ToArray();
        }
        void loadd_all_Font()
        {
            comboBox2.Items.Clear();
            fontList.Clear();

            string headerPath = "MyFontMaker.h";     // Đường dẫn file .h
            string sourcePath = "MyFontMaker.cpp";   // Đường dẫn file .cpp

            try
            {
                string headerText = File.ReadAllText(headerPath);
                string sourceText = File.ReadAllText(sourcePath);

                // Step 1: Tìm tất cả biến extern MyFont_typedef
                var externRegex = new Regex(@"extern\s+const\s+MyFont_typedef\s+(\w+);");
                var matches = externRegex.Matches(headerText);
                Console.WriteLine($"📝 Found {matches.Count} fonts in header file.");

                foreach (Match match in matches)
                {
                    string fontVar = match.Groups[1].Value;

                    // Step 2: Tìm định nghĩa biến trong .cpp
                    var assignRegex = new Regex($@"const\s+MyFont_typedef\s+{fontVar}\s*=\s*\{{(\w+),\s*(\w+)\}};");
                    var assignMatch = assignRegex.Match(sourceText);
                    if (!assignMatch.Success)
                    {
                        Console.WriteLine($"⚠️ Font {fontVar} not initialized in .cpp");
                        continue;
                    }

                    string f_name_var = assignMatch.Groups[1].Value;
                    string f_map_var = assignMatch.Groups[2].Value;

                    byte[] f_name_data = ExtractByteArray(sourceText, f_name_var);
                    ushort[] f_map_data = ExtractUShortArray(sourceText, f_map_var);

                    if (f_name_data == null || f_map_data == null)
                    {
                        Console.WriteLine($"❌ Failed to extract data for {fontVar}");
                        continue;
                    }

                    fontList.Add(new MyFont_typedef
                    {
                        f_name = f_name_data,
                        f_map = f_map_data
                    });
                    comboBox2.Items.Add(fontVar);
                    comboBox2.SelectedIndex = comboBox2.Items.Count - 1;

                    Console.WriteLine($"✅ Font {fontVar} added. Bytes: {f_name_data.Length}, Map: {f_map_data.Length}");
                }

                Console.WriteLine($"🎉 Tổng cộng: {fontList.Count} font đã load vào danh sách.");
            }
            catch { }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //pictureBox2.BackColor = Color.Transparent;
            comboBox1.Items.Add("IOT47 UTF-8 (VN)");
            //comboBox1.Items.Add("IOT47 VNI (VN)");

            loadd_all_Font();

            comboBox1.SelectedIndex = 0;

            textBox5.Text = Properties.Settings.Default.mabosung ?? "";
        }
        int starty, dodaiFont;
        private void button1_Click(object sender, EventArgs e)
        {
            FontDialog dlg = new FontDialog();
            dlg.Font = textBox2.Font;
            if (fontName != "" && fontSize != 0)
            {
                dlg.Font = font_select;
            }

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                font_select = dlg.Font;
                fontName = dlg.Font.Name;
                fontSize = dlg.Font.Size;
                textBox2.Text = fontName;
                textBox3.Text = fontSize.ToString();
                Font Font = new Font(fontName, textBox2.Font.Size);
                textBox1.Font = Font;
                draw_font(textBox1.Text, 0);
            }
        }
        Bitmap draw_font(String Text, int kt)
        {
            int bmH, bmW;
            Bitmap bitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            if (kt==0)
            { 
                if (textBox1.Text == "") { /*MessageBox.Show("Vui lòng chọn bộ mã hoặc tự gõ bộ mã của riêng bạn"); */ return bitmap; }
                if (textBox3.Text == "") { MessageBox.Show("Vui lòng chọn font kiểu UTF8 có sẵn trong máy tính của bạn"); return bitmap; }
                if (textBox1.Text == "") { MessageBox.Show("Vui lòng chọn font kiểu UTF8 có sẵn trong máy tính của bạn"); return bitmap; }
            }
            pictureBox1.Size = new Size(pictureBox1.Width, pictureBox1.Height);
            try
            {
                PointF Location = new PointF(0, 0);
                //fill while
                Graphics gfx = Graphics.FromImage(bitmap);
                SolidBrush brush = new SolidBrush(Color.FromArgb(255, 255, 255));
                gfx.FillRectangle(brush, 0, 0, bitmap.Width, bitmap.Height);
                Graphics graphics = Graphics.FromImage(bitmap);
                Font Font = font_select;
                graphics.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
                graphics.DrawString(Text, Font, Brushes.Black, Location);
            }
            catch
            { 
                return bitmap;
            }
 
            int minx = bitmap.Width, miny = bitmap.Height, maxx = 0, maxy = 0;
            for (int x = 0; x < bitmap.Width; x++) //tìm điểu cuối xy
            {
                for (int y = 0; y < bitmap.Height; y++)
                {
                    Color c = bitmap.GetPixel(x, y);
                    if (c.R == 0 && c.G == 0 && c.B == 0)
                    {
                        if (x < minx) minx = x;
                        if (y < miny) miny = y;
                    }
                }
            }
            for (int x = 0; x < bitmap.Width; x++) //tìm điểu cuối xy
            {
                for (int y = 0; y < bitmap.Height; y++)
                {
                    Color c = bitmap.GetPixel(x, y);
                    if (c.R == 0 && c.G == 0 && c.B == 0)
                    {
                        if (x > maxx) maxx = x;
                        if (y > maxy) maxy = y;
                    }
                }
            }
            if (maxx == 0 && maxy == 0)
            {
                minx = 0;
                miny = 0;
                maxx = Int16.Parse(numericUpDown1.Text)-1;
                maxy = 0;
            }
            //if (maxy > mid_line) offset = maxy - mid_line - 1;
            //else offset = 0;

            bmW = bitmap.Width;
            bmH = bitmap.Height;

            starty = miny;
            if (kt == 0) pictureBox1.Image = CropImage(bitmap, minx, miny, maxx, maxy);
            return CropImage(bitmap, minx, miny, maxx, maxy);
        }
        public static Bitmap CropImage(Image source, int x, int y, int x1, int y1)
        {
            int Width = x1 - x + 1;
            int Height = y1 - y + 1;
            Rectangle crop = new Rectangle(x, y, Width, Height);

            var bmp = new Bitmap(crop.Width, crop.Height);
            using (var gr = Graphics.FromImage(bmp))
            {
                gr.DrawImage(source, new Rectangle(0, 0, bmp.Width, bmp.Height), crop, GraphicsUnit.Pixel);
            }
            return bmp;
        }
        public Bitmap ResizeBitmap(Bitmap bmp, int width, int height)
        {
            Bitmap result = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(result))
            {
                g.DrawImage(bmp, 0, 0, width, height);
            }

            return result;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            try { fontSize = Int16.Parse(textBox3.Text); draw_font(textBox1.Text,0); }
            catch { }
        }
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            //Bitmap bmp = ResizeBitmap((Bitmap)pictureBox1.Image, 100,200);
            //pictureBox1.Image = bmp;
        }
        String f_map, f_dat;
        String font_name_clear;
        void creat_font()
        {
            StringBuilder font_map = new StringBuilder();
            StringBuilder font_dat = new StringBuilder();
            int dem = 1,line=0;
            int tam = 0, heso = 1;
            byte giatri = 0;
            Bitmap a = draw_font("Ẩ", 1); //utf-8
            //if (type_font==0) a=draw_font("Ẩ", 1); //utf-8
            //else a = draw_font("AÁ", 1); //VNI WINDOW
            String promem = "";
            promem = " PROGMEM ";
            font_name_clear = textBox2.Text.Replace(" ", "_"); font_name_clear = font_name_clear.Replace("-", "_");
            font_name_clear += RandomString(10);
            font_map.Append("//(C) 2020 By Dao Nguyen IOT47.com\r\nconst uint16_t " + promem + font_name_clear + "_MAP[]" + "={\r\n");
            font_dat.Append("//(C) 2020 By Dao Nguyen IOT47.com\r\nconst uint8_t " + promem + font_name_clear + "[]" + "={\r\n" + (maxHChar).ToString() + ",\r\n");
            for (int i = 0; i < textBox1.Text.Length; i++)
            {
                String c = textBox1.Text[i].ToString();
                Bitmap f = draw_font(c, 1); //láy kí tự ra
                font_dat.Append(f.Width.ToString() + "," + f.Height.ToString() + "," + (int)Math.Ceiling((double)f.Width/8) + "," + starty.ToString() + ",\r\n");
                dem += 4;
                font_map.Append(dem.ToString() + ",");
                for (int h = 0; h < f.Height; h++)
                {
                    for (int x = 0; x < f.Width / 8; x++)
                    {
                        giatri = 0;
                        for (int y = 0; y < 8; y++)
                        {
                            heso = 1;
                            Color p = f.GetPixel(y + (x * 8), h);
                            if ((int)p.R == 0) tam = 1;
                            else tam = 0;

                            for (int pos = 7; pos > y; pos--) heso *= 2;
                            tam *= heso;
                            giatri += (byte)tam;
                        }
                        dem++;
                        font_dat.Append("0x" + giatri.ToString("X2") + ",");
                    }
                    if (f.Width % 8 != 0) // nếu vẫn còn dư
                    {
                        int du = f.Width / 8;
                        giatri = 0;
                        for (int y = 0; y < f.Width % 8; y++)
                        {
                            heso = 1;
                            Color p = f.GetPixel(y + (du * 8), h);
                            if ((int)p.R == 0) tam = 1;
                            else tam = 0;

                            for (int pos = 7; pos > y; pos--) heso *= 2;
                            tam *= heso;
                            giatri += (byte)tam;
                        }
                        dem++;
                        font_dat.Append("0x" + giatri.ToString("X2") + ",");
                    }
                }
                if (c == "\\") c =" ";
                font_dat.Append("//" + c + "\r\n");
                line++;
                if(line%16==0) font_map.Append("\r\n");
            }

            font_map.Append("\r\n};\r\n");
            font_dat.Append("\r\n};\r\n");
            f_map = font_map.ToString();
            f_dat = font_dat.ToString();
        }
        private static Random random = new Random();
        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        String boma;
        void creat_ma()
        {
            String ma = textBox1.Text + textBox5.Text;

            int len = ma.Length;
            //int len2 = Encoding.UTF8.GetByteCount(textBox1.Text);
            StringBuilder bo_ma = new StringBuilder();         
            for (int i = 0; i < len; i++)
            {
                String c = ma[i].ToString();
                //UInt32 value = getUTF8_HexValue(c);
                String hexUTF8 = GetUtf8Hex(c);
                if (c == "\\") c = "";
                if (i == 0) hexUTF8 = "0x00000000";
                bo_ma.Append(hexUTF8 + ", //" + c.ToString() + "\r\n");
            }
            boma = bo_ma.ToString();  
        }
        private Thread coding;
        private Thread coding2;

        void getMaxHchar()
        {
            maxHChar = 0; maxStartHChar = 0;
            for (int i = 0; i < textBox1.Text.Length; i++)
            {
                String c = textBox1.Text[i].ToString();
                Bitmap f = draw_font(c, 1); //láy kí tự ra
                if (f.Height > maxHChar)
                {
                    maxHChar = f.Height;
                    maxStartHChar = starty;
                }
            }
        }

        static readonly string[] CKeywords = new string[]
        {
            "auto","break","case","char","const","continue","default","do","double",
            "else","enum","extern","float","for","goto","if","inline","int","long",
            "register","restrict","return","short","signed","sizeof","static",
            "struct","switch","typedef","union","unsigned","void","volatile","while",
            "_Alignas","_Alignof","_Atomic","_Bool","_Complex","_Generic","_Imaginary",
            "_Noreturn","_Static_assert","_Thread_local"
        };

        static bool IsValidCVariableName(string name)
        {
            if (string.IsNullOrEmpty(name))
                return false;

            // Regex: bắt đầu bằng chữ cái hoặc _, sau đó là chữ/số/_
            if (!Regex.IsMatch(name, @"^[A-Za-z_][A-Za-z0-9_]*$"))
                return false;

            // Không được là từ khóa
            foreach (var kw in CKeywords)
            {
                if (name == kw)
                    return false;
            }

            return true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                MessageBox.Show("Vui lòng điền tên bộ font của bạn, nó sẽ được sử dụng trong code Arduino IDE");
                return;
            }
            if(!IsValidCVariableName(textBox6.Text))
            {
                MessageBox.Show("Vui lòng điền tên bộ font của bạn theo đúng quy tắc đặt tên biến trong C");
                return;
            }    
            if (textBox1.Text == "") { MessageBox.Show("Vui lòng chọn bộ mã hoặc tự gõ bộ mã của riêng bạn"); return ; }
            if (textBox3.Text == "") { MessageBox.Show("Vui lòng chọn font kiểu UTF8 có sẵn trong máy tính của bạn"); return ; }
            if (textBox1.Text == "") { MessageBox.Show("Vui lòng chọn font kiểu UTF8 có sẵn trong máy tính của bạn"); return ; }
            pictureBox2.Visible = true;
            button5.Enabled = false;
            Application.DoEvents(); // Bắt UI update ngay lập tức
            Properties.Settings.Default.mabosung = textBox5.Text;
            Properties.Settings.Default.Save();

            coding = new Thread(delegate () {
                getMaxHchar();
                draw_font(textBox1.Text, 0);
                creat_font();
                creat_ma();
                BeginInvoke((MethodInvoker)delegate () {
                    pictureBox2.Visible = false;
                    //xong
                    String linker = "";
                
                    String MyFontMaker_h = linker + "MyFontMaker.h";
                    if (File.Exists(MyFontMaker_h)) // nếu đã tồn tại file đó
                    {
                        using (System.IO.StreamReader Reader = new System.IO.StreamReader(MyFontMaker_h))
                        {
                            string fileContent = Reader.ReadToEnd();
                            Reader.Close();
                            if(fileContent.IndexOf(textBox6.Text) != -1)
                            {
                                MessageBox.Show("Có vẻ như " + textBox6.Text + " đã tồn tại, hãy đặt 1 cái tên khác");
                                button5.Enabled = true;
                                return;
                            }
                            fileContent = fileContent.Replace("//auto add here", "extern const MyFont_typedef " + textBox6.Text + ";\r\n//auto add here");
                            File.WriteAllText(MyFontMaker_h, fileContent);
                        }
                        String MyFontMaker = linker + "MyFontMaker.cpp";
                        if (File.Exists(MyFontMaker)) // nếu đã tồn tại file đó
                        {
                            using (System.IO.StreamReader Reader = new System.IO.StreamReader(MyFontMaker))
                            {
                                string fileContent = Reader.ReadToEnd();
                                Reader.Close();
                                fileContent = fileContent.Replace("//auto add here", f_dat + "\r\n" + f_map + "\r\nconst MyFont_typedef " + textBox6.Text + " = {" + font_name_clear + "," + font_name_clear + "_MAP};" + "\r\n//auto add here");
                                File.WriteAllText(MyFontMaker, fileContent);
                            }
                            String UTF_Cpp = linker + "IOT47_UTF8.cpp";
                            if (File.Exists(UTF_Cpp)) // nếu đã tồn tại file đó
                            {
                                using (System.IO.StreamReader Reader = new System.IO.StreamReader(UTF_Cpp))
                                {
                                    string fileContent = Reader.ReadToEnd();
                                    Reader.Close();
                                    int start = fileContent.IndexOf("/*add_here1*/");
                                    int end = fileContent.IndexOf("//data_add_xxx");
                                    fileContent = fileContent.Remove(start + 15, end - start - 16);
                                    fileContent = fileContent.Replace("//data_add_xxx", boma + "\r\n//data_add_xxx");
                                    File.WriteAllText(UTF_Cpp, fileContent);

                                    MessageBox.Show("Đã thêm font vào thư viện");
                                    button5.Enabled = true;
                                    loadd_all_Font();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Không tìm thấy file thư viện");
                                button5.Enabled = true;
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy file thư viện");
                            button5.Enabled = true;
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy file thư viện");
                        button5.Enabled = true;
                        return;
                    }
                });
            });
            coding.IsBackground = true;
            coding.Start();

            //coding2 = new Thread(delegate () {
            //    creat_ma();
            //    BeginInvoke((MethodInvoker)delegate () {
                     
            //    });
            //});
            //coding2.IsBackground = true;
            //coding2.Start();
        }
        int mov, movX, movY;
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.Location.X;
            movY = e.Location.Y;
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            int y = 5;
            int appX = this.Location.X;
            int appY = this.Location.Y;
            for (double i = 1; i > 0; i = i - 0.1)
            {
                this.Opacity = i;
                this.SetDesktopLocation(this.Location.X, MousePosition.Y + y);
                y = (int)((y + 15) / i);
                Thread.Sleep(30);
            }
            this.SetDesktopLocation(appX, appY);
            this.WindowState = FormWindowState.Minimized;
            this.Opacity = 1;
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            for (double i = 1; i > 0; i = i - 0.1)
            {
                this.Opacity = i;
                Thread.Sleep(30);
            }
            Application.Exit();
        }
        //UInt32 getUTF8_HexValue(String c)
        //{
        //    UInt32 value=0;
        //    byte[] bytes = Encoding.UTF8.GetBytes(c);
        //    for(int i=0;i< bytes.Length;i++)
        //    {
        //        value <<= 8;
        //        value |= bytes[i];
        //    }
        //    return value;
        //}
        string GetUtf8Hex(string ch)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(ch);

            // Ghép các byte thành 1 số nguyên 32-bit
            int value = 0;
            foreach (byte b in bytes)
            {
                value = (value << 8) | b;
            }

            // Xuất dạng "0x0000C2B0"
            return "0x" + value.ToString("X8");
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            int f_index = comboBox2.SelectedIndex;
            if(f_index >= 0 && fontList.Count > 0)
            {
                Bitmap bitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                fontList[f_index].print(0, 0, textBox4.Text, Color.Black, bitmap);
                pictureBox1.Image = bitmap;
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            int f_index = comboBox2.SelectedIndex;
            if (f_index >= 0 && fontList.Count > 0)
            {
                Bitmap f = fontList[f_index].getBitmap(comboBox3.Text);
                FontEditForm editor = new FontEditForm(f, fontList[f_index].getstart_y(comboBox3.Text));
                if (editor.ShowDialog() == DialogResult.OK)
                {
                    f = editor.EditedBitmap;
                    StringBuilder font_dat = new StringBuilder();
                    int tam = 0, heso = 1;
                    byte giatri = 0;
                    List<byte> list_dat_new = new List<byte>();
                    for (int h = 0; h < f.Height; h++)
                    {
                        for (int x = 0; x < f.Width / 8; x++)
                        {
                            giatri = 0;
                            for (int y = 0; y < 8; y++)
                            {
                                heso = 1;
                                Color p = f.GetPixel(y + (x * 8), h);
                                if ((int)p.R == 0) tam = 1;
                                else tam = 0;

                                for (int pos = 7; pos > y; pos--) heso *= 2;
                                tam *= heso;
                                giatri += (byte)tam;
                            }
                            font_dat.Append("0x" + giatri.ToString("X2") + ",");
                            list_dat_new.Add(giatri);
                        }
                        if (f.Width % 8 != 0) // nếu vẫn còn dư
                        {
                            int du = f.Width / 8;
                            giatri = 0;
                            for (int y = 0; y < f.Width % 8; y++)
                            {
                                heso = 1;
                                Color p = f.GetPixel(y + (du * 8), h);
                                if ((int)p.R == 0) tam = 1;
                                else tam = 0;

                                for (int pos = 7; pos > y; pos--) heso *= 2;
                                tam *= heso;
                                giatri += (byte)tam;
                            }
                            font_dat.Append("0x" + giatri.ToString("X2") + ",");
                            list_dat_new.Add(giatri);
                        }
                    }
                    String old = fontList[f_index].getStringFont(comboBox3.Text);

                    string filePath = "MyFontMaker.cpp";   // Đường dẫn file .cpp

                    // Đọc toàn bộ nội dung file
                    string content = File.ReadAllText(filePath);
                    // Thay thế nội dung
                    string updatedContent = content.Replace(old, font_dat.ToString());

                    // Ghi lại vào file (ghi đè)
                    File.WriteAllText(filePath, updatedContent);
                    fontList[f_index].updateFont(comboBox3.Text, list_dat_new);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn 1 bộ font mà bạn đã tạo");
            }    
        }

        // Trả về true nếu người dùng chọn Yes
        public static bool Confirm(string text, string caption = "Xác nhận")
        {
            var r = System.Windows.Forms.MessageBox.Show(
                text,
                caption,
                System.Windows.Forms.MessageBoxButtons.YesNo,
                System.Windows.Forms.MessageBoxIcon.Question,
                System.Windows.Forms.MessageBoxDefaultButton.Button2 // mặc định No
            );
            return r == System.Windows.Forms.DialogResult.Yes;
        }
        public static bool RemoveFontByName(string fontVarName, string myFontMakerCppPath, params string[] otherFilePaths)
        {
            if (string.IsNullOrWhiteSpace(fontVarName))
                throw new ArgumentException("fontVarName rỗng.");

            if (string.IsNullOrWhiteSpace(myFontMakerCppPath) || !File.Exists(myFontMakerCppPath))
                throw new FileNotFoundException("Không tìm thấy MyFontMaker.cpp", myFontMakerCppPath);

            // 1) Đọc MyFontMaker.cpp để lấy tên 2 mảng
            string cppText = File.ReadAllText(myFontMakerCppPath);

            var reTypedef = new Regex(
                @"const\s+MyFont_typedef\s+" + Regex.Escape(fontVarName) + @"\s*=\s*\{\s*([A-Za-z_]\w*)\s*,\s*([A-Za-z_]\w*)\s*\}\s*;",
                RegexOptions.Multiline);

            var m = reTypedef.Match(cppText);
            if (!m.Success)
            {
                // Không thấy dòng typedef tương ứng
                return false;
            }

            string glyphId = m.Groups[1].Value; // ví dụ: Microsoft_Sans_Serif9DDKXSA2W8
            string mapId = m.Groups[2].Value; // ví dụ: Microsoft_Sans_Serif9DDKXSA2W8_MAP

            // 2) Regex xóa mảng
            var reGlyph = new Regex(
                @"const\s+uint8_t(?:\s+PROGMEM)?\s+" + Regex.Escape(glyphId) + @"\s*\[\]\s*=\s*\{[\s\S]*?\};\s*",
                RegexOptions.Multiline);

            var reMap = new Regex(
                @"const\s+uint16_t(?:\s+PROGMEM)?\s+" + Regex.Escape(mapId) + @"\s*\[\]\s*=\s*\{[\s\S]*?\};\s*",
                RegexOptions.Multiline);

            // 3) Danh sách file cần xử lý: MyFontMaker.cpp + các file khác (nếu có)
            var files = new List<string>();
            files.Add(myFontMakerCppPath);
            if (otherFilePaths != null)
            {
                foreach (var p in otherFilePaths)
                    if (!string.IsNullOrWhiteSpace(p) && File.Exists(p) && !files.Contains(p))
                        files.Add(p);
            }

            bool removedAnything = false;

            foreach (var path in files)
            {
                string text = File.ReadAllText(path);

                // Sao lưu đơn giản (.bak) trước khi ghi
                try { File.Copy(path, path + ".bak", true); } catch { /* bỏ qua nếu không sao lưu được */ }

                // xóa mảng glyph + map
                string newText = reGlyph.Replace(text, match =>
                {
                    removedAnything = true;
                    return string.Empty;
                });

                newText = reMap.Replace(newText, match =>
                {
                    removedAnything = true;
                    return string.Empty;
                });

                // xóa dòng typedef chỉ khi đang ở MyFontMaker.cpp (nhưng chạy ở file khác cũng không sao, sẽ không match)
                newText = reTypedef.Replace(newText, match =>
                {
                    removedAnything = true;
                    return string.Empty;
                }, 1); // chỉ cần xóa 1 lần

                if (!ReferenceEquals(text, newText) && text != newText)
                {
                    File.WriteAllText(path, newText);
                }
            }

            return removedAnything;
        }
        public static bool RemoveExternInHeader(string fontVarName)
        {
            if (string.IsNullOrWhiteSpace(fontVarName))
                throw new ArgumentException("fontVarName rỗng.");

            // Tìm file MyFontMaker.h ở BaseDirectory rồi đến CurrentDirectory
            string[] tryPaths = new[]
            {
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MyFontMaker.h"),
            Path.Combine(Environment.CurrentDirectory, "MyFontMaker.h")
        };

            string headerPath = null;
            foreach (var p in tryPaths)
            {
                if (File.Exists(p)) { headerPath = p; break; }
            }

            if (headerPath == null)
                throw new FileNotFoundException("Không tìm thấy MyFontMaker.h trong thư mục chạy hoặc thư mục hiện tại.");

            // Regex match đúng 1 dòng extern (linh hoạt khoảng trắng), xóa cả xuống dòng liền sau nếu có
            var reExtern = new Regex(
                @"^\s*extern\s+const\s+MyFont_typedef\s+" + Regex.Escape(fontVarName) + @"\s*;\s*(?:\r?\n)?",
                RegexOptions.Multiline
            );

            string text = File.ReadAllText(headerPath);
            string newText = reExtern.Replace(text, string.Empty);

            if (text != newText)
            {
                try { File.Copy(headerPath, headerPath + ".bak", true); } catch { /* optional */ }
                File.WriteAllText(headerPath, newText);
                return true;
            }

            return false;
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (Confirm("Bạn có chắc muốn xóa vĩnh viễn font " + comboBox2.Text + " ?")) 
            {
                if(RemoveFontByName(comboBox2.Text, "MyFontMaker.cpp",null))
                {
                    RemoveExternInHeader(comboBox2.Text);
                    MessageBox.Show("Đã xóa font");
                    loadd_all_Font();
                }    
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mov == 1)
                this.SetDesktopLocation(MousePosition.X - movX , MousePosition.Y - movY);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0) //unicode UTF-8
            {
                textBox1.Text = " ÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬĐÈÉẺẼẸÊỀẾỂỄỆÌÍ !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~ỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴàáảãạăằắẳẵặâầấẩẫậđèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵ你好朋友❤°";
            }
            for (int i = 0; i < textBox1.Text.Length; i++)
            {
                comboBox3.Items.Add(textBox1.Text[i]);
            }
            //else if (comboBox1.SelectedIndex == 1) //VNI Window
            //{
            //    MessageBox.Show("Thứ lỗi ! Chưa hỗ trợ bộ mã VNI, hãy dùng bộ mã UTF-8 nhé !");
            //    comboBox1.SelectedIndex = 0;
            //    return;
            //    type_font = 1;
            //    textBox1.Text = "AØAÙAÛAÕAÏAÊAÈAÉAÚAÜAËAÂAÂAÀAÁAÅAÃAÄÑEØEÙEÛEÕEÏEÂEÀEÁEÅEÃEÄÌÍ!\"#$%&‘()*+,–./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~ÆÓÒOØOÙOÛOÕOOÂOÀOÁOÅOÃOÄÔÔØÔÙÔÛÔÕÔÏUØUÙUÛUÕUÏÖÖØÖÙÖÛÖÕÖÏYØYÙYÛYÕÎaøaùaûaõaïaêaèaéaúaüaëaâaàaáaåaãaäñeøeùeûeõeïeâeàeáeåeäìíæóòoøoùoûoõoïoâoàoáoåoãoäôôøôùôûôõôïuøuùuûuõuïööøöùöûöõöïyøyùyûyõî";
            //}
            //draw_font(textBox1.Text, 0);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Truy cập iot47.com để xem hướng dẫn");
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if(Int16.Parse(numericUpDown1.Text) <= 0)
            {
                numericUpDown1.Text = "0";
            }
        }
    }
}
